
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>
#include <ctype.h>

#define NUM_MAX_TUTORES 720 // TAMB�M USADO PARA DELIMITAR O VETOR DE ESTRUTURAS DE ENDERE�O
#define NUM_MAX_ANIMAIS 1024

typedef struct Endereco{

    int cep[8];
    char rua[120];
    char bairro[120];
    char cidade [80];
    char estado[50];
    char numero_casa[50];


}Endereco;

typedef struct Forma_contato{

    int telefone[11];
    char email[120];


}Forma_contato;


typedef struct Tutor {

    int tutor_ocupado;
    char nome_tutor[256];
    int id_tutor;
    int id_animais[10];
    int cpf[11];
    char sexo;
    Endereco endereco;
    Forma_contato contato;
} Tutor;

typedef struct Animal {
    int ocupado;
    char nome_animal[256];
    int id_animal;
    int id_tutor;
    char especie[256];
    char sexo;
    char raca[256];
    char vacinas[512];
    char vermifugado;
    char historico[512];
    char castrado;
} Animal;

Tutor vetor_tutores[NUM_MAX_TUTORES];
Animal vetor_animais[NUM_MAX_ANIMAIS];
int total_animais = 0;
int total_tutores = 0; // PRESTA ATENCAO EM TUDO
char caminho_arquivo_animais[256] = "animais.txt";
char caminho_arquivo_tutores[256] = "tutores.txt";

// Fun��es
void cadastro_inicializar_animais();
void cadastro_inicializar_tutores(); // AQUI FIO
void cadastro_inicializar_arquivo_animais();
void cadastro_inicializar_arquivo_tutores();
void cadastro_carregar_dados_arquivo_animais();
void cadastro_carregar_dados_arquivo_tutores(); // AQUI FIO
void cadastro_salvar_dados_arquivo_animais();
void cadastro_salvar_dados_arquivo_tutores(); // AQUI FIO
int cadastro_verificar_capacidade_maxima_animais();
int cadastro_verificar_capacidade_maxima_tutores();// AQUI FIO
int verificar_id_animal_existente(int id);
int verificar_id_tutor_existente(int id);
int verificar_id_tutor_existente2(int id);
void cadastro_inserir_animal(Animal animal);
Animal cadastro_pesquisar_animal(int id);
void cadastro_inserir_tutor(Tutor tutor);// AQUI
Tutor cadastro_pesquisar_tutor(int id);// E AQUI
int cadastro_remover_animal(int id);
int cadastro_remover_tutor(int id);
int novo_tutor_cadatro_animal(); // CADASTRA UM NOVO TUTOR, DURANTE O CADASTRO DO ANIMAL
int novo_animal_cadatro_tutor(); // CADASTRA UM NOVO ANIMAL, DURANTE O CADASTRO DO TUTOR
int qtde_animais_cadastrados_tutor(int id_tutor);
Tutor animais_id_tutor_inicializador();


// Telas
void marcas(int tela);
int tela_menu_opcoes();
int tela_novo_tutor_cadatro_animal(int id_tutor, int id_animal); // TELA DE UM NOVO TUTOR, DURANTE O CADASTRO DO ANIMAL
int tela_novo_animal_cadatro_tutor(int id_animal, int id_tutor); // TELA DE UM NOVO ANIMAL, DURANTE O CADASTRO DO TUTOR
Endereco tela_cadastar_endereco();
Forma_contato tela_cadastrar_forma_contato();
void tela_cadastrar_animal();
void tela_cadastrar_tutor();// AQUI FIO
void tela_relatorio();
void tela_relatorio_animais();
void tela_relatorio_tutores();
void tela_pesquisar();
void tela_pesquisar_tutor();
void tela_remover();
void tela_remover_tutor();
int tela_sair();
int tela_mensagem(char *mensagem);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int main() {
    setlocale(LC_ALL, "");
    system("chcp 1252 > nul");

    int sair = 0;
    int opcao;

    cadastro_inicializar_animais();
    cadastro_inicializar_tutores();
    cadastro_inicializar_arquivo_tutores();
    cadastro_inicializar_arquivo_animais();
    cadastro_carregar_dados_arquivo_tutores();
    cadastro_carregar_dados_arquivo_animais();
    marcas(0);

    do {
        opcao = tela_menu_opcoes();
        switch(opcao) {
            case 1:
                tela_cadastrar_animal();
                break;

            case 2:
                tela_cadastrar_tutor();
                break;

            case 3:
                tela_relatorio();
                break;

            case 4:
                tela_pesquisar();
                break;

            case 5:
                tela_pesquisar_tutor();
                break;

            case 6:
                tela_remover();
                break;

            case 7:
                tela_remover_tutor();
                break;

            case 8:
                sair = tela_sair();
                break;

            default:
                printf("\nOp��o Inv�lida !!! \n");
                system("pause");
        }
    } while(sair == 0);

    cadastro_salvar_dados_arquivo_animais();
    cadastro_salvar_dados_arquivo_tutores();

    system("cls");
    printf("\nFim da execu��o do programa!\n");

    return 0;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////// TELAS///////////////////////////////////////////

void marcas(int tela) {
    if(tela == 0){
        printf("\t\t\t\t                                                                          \n");
        printf("\t\t\t\t                                                                          \n");
        printf("\t\t\t\t                         @@@@@@@@@             @@@@@@@@@@                  \n");
        printf("\t\t\t\t                       @@@@@@@@@@@@@         @@@@@@@@@@@@@                 \n");
        printf("\t\t\t\t                      @@@@@@@@@@@@@@@@      @@@@@@@@@@@@@@@                \n");
        printf("\t\t\t\t                      @@@@@@@@@@@@@@@@@    @@@@@@@@@@@@@@@@@              \n");
        printf("\t\t\t\t                      @@@@@@@@@@@@@@@@@    @@@@@@@@@@@@@@@@@              \n");
        printf("\t\t\t\t                      @@@@@@@@@@@@@@@@@   @@@@@@@@@@@@@@@@@@              \n");
        printf("\t\t\t\t                      @@@@@@@@@@@@@@@@@   @@@@@@@@@@@@@@@@@                \n");
        printf("\t\t\t\t                       @@@@@@@@@@@@@@@@   @@@@@@@@@@@@@@@@@                \n");
        printf("\t\t\t\t                        @@@@@@@@@@@@@@@    @@@@@@@@@@@@@@@    @@@@@@@     \n");
        printf("\t\t\t\t            @@@@@@@@@     @@@@@@@@@@@@      @@@@@@@@@@@@   @@@@@@@@@@@@   \n");
        printf("\t\t\t\t          @@@@@@@@@@@@@     @@@@@@@@          @@@@@@@@    @@@@@@@@@@@@@@  \n");
        printf("\t\t\t\t          @@@@@@@@@@@@@@@                               @@@@@@@@@@@@@@@@  \n");
        printf("\t\t\t\t          @@@@@@@@@@@@@@@@                              @@@@@@@@@@@@@@@@  \n");
        printf("\t\t\t\t          @@@@@@@@@@@@@@@@@                            @@@@@@@@@@@@@@@@@  \n");
        printf("\t\t\t\t          @@@@@@@@@@@@@@@@@           @@@@@@@          @@@@@@@@@@@@@@@@@  \n");
        printf("\t\t\t\t           @@@@@@@@@@@@@@@@      @@@@@@@@@@@@@@@@@     @@@@@@@@@@@@@@@@   \n");
        printf("\t\t\t\t            @@@@@@@@@@@@@@@   @@@@@@@@@@@@@@@@@@@@@@    @@@@@@@@@@@@@     \n");
        printf("\t\t\t\t             @@@@@@@@@@@@  @@@@@@@@@@@@@@@@@@@@@@@@@@@  @@@@@@@@@@       \n");
        printf("\t\t\t\t                 @@@@@@   @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@                  \n");
        printf("\t\t\t\t                         @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@                 \n");
        printf("\t\t\t\t                        @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@                \n");
        printf("\t\t\t\t                       @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@              \n");
        printf("\t\t\t\t                      @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@             \n");
        printf("\t\t\t\t                     @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@            \n");
        printf("\t\t\t\t                     @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@            \n");
        printf("\t\t\t\t                     @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@           \n");
        printf("\t\t\t\t                      @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@            \n");
        printf("\t\t\t\t                       @@@@@@@@@@@@               @@@@@@@@@@@@             \n");
        printf("\t\t\t\t                                                                           \n\n\n");

        printf("\t\t\t\t\tSavingPets - Sistema Gerenciador de P�s ado��o de Animais Resgatados\n\n\n");
        system("pause");
    }else if(tela == 1){

        printf("\t\t\t\t           /\\_/\\   \n");
        printf("\t\t\t\t          ( o.o )  \n");
        printf("\t\t\t\t           > ^ <   \n");

    }else if(tela == 2){

        printf("\t\t\t\t           /^ ^\\ \n");
        printf("\t\t\t\t          / 0 0 \\ \n");
        printf("\t\t\t\t          V\\ Y /V \n");
        printf("\t\t\t\t           / - \\  \n");
        printf("\t\t\t\t          |    \\\\\n");
        printf("\t\t\t\t          || (__V \n");

    }
}


int tela_menu_opcoes() {
    int opcao, erro;
    system("cls");
    printf("***** Menu de Op��es *****\n");
    printf("1 - Cadastrar Animal\n");
    printf("2 - Cadastrar Tutor\n");
    printf("3 - Relat�rio Geral de Animais Cadastrados\n");
    printf("4 - Pesquisar Animal por ID\n");
    printf("5 - Pesquisar Tutor por ID\n");
    printf("6 - Remover Animal\n");
    printf("7 - Remover Tutor\n");
    printf("8 - Sair\n\n");
    printf("Escolha uma op��o: ");

    erro = scanf("%d", &opcao);
    fflush(stdin);

    if(erro != 1) {
         opcao = -1;
    }

    return opcao;
}

int tela_novo_tutor_cadatro_animal(int id_tutor, int id_animal) {

    printf("oi");
    return 1;

}

int tela_novo_animal_cadatro_tutor(int id_animal, int id_tutor) {
    Animal a;
    a.ocupado = 0; // Inicializa como n�o ocupado

    system("cls");
    printf("--- Cadastro de Novo Animal ---\n");

    if (cadastro_verificar_capacidade_maxima_animais() == 1) {
        printf("Erro: Capacidade m�xima de animais atingida!\n");
        system("pause");
        return 0;
    }

    a.id_animal = id_animal;
    a.id_tutor = id_tutor;

    printf("Nome do animal: ");
    fgets(a.nome_animal, 256, stdin);
    a.nome_animal[strcspn(a.nome_animal, "\n")] = 0;

    printf("Esp�cie: ");
    fgets(a.especie, 256, stdin);
    a.especie[strcspn(a.especie, "\n")] = 0;

    printf("Sexo (M/F): ");
    scanf(" %c", &a.sexo);
    fflush(stdin);

    printf("Ra�a: ");
    fgets(a.raca, 256, stdin);
    a.raca[strcspn(a.raca, "\n")] = 0;

    printf("Vacinas: ");
    fgets(a.vacinas, 512, stdin);
    a.vacinas[strcspn(a.vacinas, "\n")] = 0;

    printf("Vermifugado (S/N): ");
    scanf(" %c", &a.vermifugado);
    fflush(stdin);

    printf("Hist�rico de sa�de: ");
    fgets(a.historico, 512, stdin);
    a.historico[strcspn(a.historico, "\n")] = 0;

    printf("Castrado (S/N): ");
    scanf(" %c", &a.castrado);
    fflush(stdin);

    a.ocupado = 1;
    cadastro_inserir_animal(a);

    printf("\nAnimal cadastrado com sucesso!\n");
    system("pause");

    return 1;
}

void tela_cadastrar_animal() {
    int continuar = 0;

    Animal a;

    do {
        system("cls");
        printf("1 - Cadastrar Animal\n");

        if (cadastro_verificar_capacidade_maxima_animais() == 1) {
            printf("Erro: Capacidade m�xima atingida!\n");
            system("pause");
            break;
        }

        printf("\nDigite o ID do animal: ");
        scanf("%d", &a.id_animal); fflush(stdin);

        if (verificar_id_animal_existente(a.id_animal)) {
            printf("Erro: ID de animal j� cadastrado!\n");
            system("pause");
            continue;
        }

        printf("Digite o ID do tutor: ");
        scanf("%d", &a.id_tutor); fflush(stdin);

        if (!verificar_id_tutor_existente(a.id_tutor)) {
            printf("Erro: ID de tutor inexistente!\n");
            system("pause");
            continue;
        }

        printf("Digite o nome do animal: ");
        fgets(a.nome_animal, 256, stdin);
        a.nome_animal[strcspn(a.nome_animal, "\n")] = 0;

        printf("Digite a esp�cie: ");
        fgets(a.especie, 256, stdin);
        a.especie[strcspn(a.especie, "\n")] = 0;

        printf("Digite o sexo (M/F): ");
        scanf(" %c", &a.sexo);
        fflush(stdin);

        printf("Digite a ra�a: ");
        fgets(a.raca, 256, stdin);
        a.raca[strcspn(a.raca, "\n")] = 0;

        printf("Digite dados de vacinas: ");
        fgets(a.vacinas, 512, stdin);
        a.vacinas[strcspn(a.vacinas, "\n")] = 0;

        printf("Vermifugado? (S/N): ");
        scanf(" %c", &a.vermifugado);
        fflush(stdin);

        printf("Digite hist�rico de doen�as: ");
        fgets(a.historico, 512, stdin);
        a.historico[strcspn(a.historico, "\n")] = 0;

        printf("Castrado? (S/N): ");
        scanf(" %c", &a.castrado);
        fflush(stdin);

        a.ocupado = 1;
        cadastro_inserir_animal(a);

    } while (continuar == 1);
}

Endereco tela_cadastar_endereco(){

    Endereco endereco;

    printf("Digite o CEP: ");
    for(int j = 0; j < 8; j++) {
            scanf("%1d", &endereco.cep[j]);  // L� 1 d�gito por vez
    }
    fflush(stdin);

    printf("Informe a rua: ");
    fgets(endereco.rua, 120, stdin);
    endereco.rua[strcspn(endereco.rua, "\n")] = 0;

    printf("Informe o bairro: ");
    fgets(endereco.bairro, 120, stdin);
    endereco.bairro[strcspn(endereco.bairro, "\n")] = 0;

    printf("Informe a cidade: ");
    fgets(endereco.cidade, 80, stdin);
    endereco.cidade[strcspn(endereco.cidade, "\n")] = 0;

    printf("Informe o estado: ");
    fgets(endereco.estado, 50, stdin);
    endereco.estado[strcspn(endereco.estado, "\n")] = 0;

    printf("Informe o n�mero da casa: ");
    fgets(endereco.numero_casa, 80, stdin);
    endereco.numero_casa[strcspn(endereco.numero_casa, "\n")] = 0;

    return endereco;

}

Forma_contato tela_cadastrar_forma_contato(){

    Forma_contato contato;

    printf("Digite o telefone com ddd: ");

        for(int j = 0; j < 11; j++) {
            scanf("%1d", &contato.telefone[j]);  // L� 1 d�gito por vez
        }
        fflush(stdin);

    printf("Digite o e-mail: ");
    scanf(" %120[^\n]", contato.email);

    return contato;

}

void tela_cadastrar_tutor() {
    int quantidade_adotados;
    char cadastrar_novo_animal;
    int continuar;

    Tutor t;
    t = animais_id_tutor_inicializador();  // Inicializa corretamente

    do {
        system("cls");
        printf("2 - Cadastrar Tutor\n");

        if (cadastro_verificar_capacidade_maxima_tutores() == 1) {
            printf("Erro: Capacidade m�xima atingida!\n");
            system("pause");
            break;
        }

        printf("\nDigite o ID do tutor: ");
        scanf("%d", &t.id_tutor); fflush(stdin);

        if (verificar_id_tutor_existente(t.id_tutor)) {
            printf("Erro: ID de tutor j� cadastrado!\n");
            system("pause");
            continue;
        }

        printf("Digite a quantidade de animais adotados: ");
        scanf("%d", &quantidade_adotados);

        if (quantidade_adotados < 1 || quantidade_adotados > 10) {
            printf("N�o � poss�vel cadastrar tutores com menos de 1 animal ou mais de 10 animais\n");
            system("pause");
            continue;
        }

        // Corre��o crucial: usar �ndice 0-based
        for(int i = 0; i < quantidade_adotados; i++) {
            int id_valido = 0;

            while (!id_valido) {
                printf("Digite o ID do %d� animal: ", i+1);
                scanf("%d", &t.id_animais[i]);
                fflush(stdin);

                if (verificar_id_animal_existente(t.id_animais[i])) {
                    id_valido = 1;
                } else {
                    printf("Erro: ID de animal inexistente!\n");
                    printf("\nDeseja cadastrar um novo animal com este ID? (S/N): ");
                    scanf(" %c", &cadastrar_novo_animal);
                    fflush(stdin);

                    if (cadastrar_novo_animal == 'S' || cadastrar_novo_animal == 's') {
                        if (tela_novo_animal_cadatro_tutor(t.id_animais[i], t.id_tutor)) {
                            id_valido = 1; // Animal foi cadastrado
                        } else {
                            printf("Falha ao cadastrar animal!\n");
                        }
                    } else {
                        t.id_animais[i] = 0; // Resetar ID inv�lido
                    }
                }
            }
        }

        printf("Digite o nome do tutor: ");
        fgets(t.nome_tutor, 256, stdin);
        t.nome_tutor[strcspn(t.nome_tutor, "\n")] = 0;

        printf("Digite o sexo do tutor (M/F): ");
        scanf(" %c", &t.sexo);
        fflush(stdin);

        printf("Digite o CPF (11 d�gitos): ");
        for(int j = 0; j < 11; j++) {
            scanf("%1d", &t.cpf[j]);
        }
        fflush(stdin);

        t.endereco = tela_cadastar_endereco();
        t.contato = tela_cadastrar_forma_contato();

        t.tutor_ocupado = 1;
        cadastro_inserir_tutor(t);

        continuar = tela_mensagem("\nGostaria de cadastrar outro tutor?");

    } while (continuar == 1);
}



void tela_relatorio() {
    int opcao, erro;
    do {
        system("cls");
        printf("***** Menu de Relat�rios *****\n");
        printf("1 - Relat�rio de Animais Cadastrados\n");
        printf("2 - Relat�rio de Tutores Cadastrados\n");
        printf("3 - Voltar ao Menu Principal\n\n");
        printf("Escolha uma op��o: ");

        erro = scanf("%d", &opcao);
        fflush(stdin);

        if(erro != 1) {
            opcao = -1;
        }

        switch(opcao) {
            case 1:
                tela_relatorio_animais();
                break;

            case 2:
                tela_relatorio_tutores();
                break;

            case 3:
                return;

            default:
                printf("\nOp��o Inv�lida !!! \n");
                system("pause");
        }
    } while(1);
}

void tela_relatorio_animais() {
    system("cls");
    printf("Relat�rio de Animais Cadastrados\n\n");
    printf("Total de Animais Cadastrados: %d\n\n", total_animais);

    for (int i = 0; i < NUM_MAX_ANIMAIS; i++) {
        if (vetor_animais[i].ocupado == 1) {
            printf("ID Animal: %d\n", vetor_animais[i].id_animal);
            printf("ID Tutor: %d\n", vetor_animais[i].id_tutor);
            printf("Nome: %s\n", vetor_animais[i].nome_animal);
            printf("Esp�cie: %s\n", vetor_animais[i].especie);
            printf("Sexo: %c\n", vetor_animais[i].sexo);
            printf("Ra�a: %s\n", vetor_animais[i].raca);
            printf("Vacinas: %s\n", vetor_animais[i].vacinas);
            printf("Vermifugado: %c\n", vetor_animais[i].vermifugado);
            printf("Hist�rico: %s\n", vetor_animais[i].historico);
            printf("Castrado: %c\n\n", vetor_animais[i].castrado);
        }
    }
    system("pause");
}

void tela_relatorio_tutores() {
    system("cls");
    printf("Relat�rio de Tutores Cadastrados\n\n");
    printf("Total de Tutores Cadastrados: %d\n\n", total_tutores);

    for (int i = 0; i < NUM_MAX_TUTORES; i++) {
        if (vetor_tutores[i].tutor_ocupado == 1) {
            printf("ID Tutor: %d\n", vetor_tutores[i].id_tutor);
            printf("Nome: %s\n", vetor_tutores[i].nome_tutor);
            printf("Sexo: %c\n", vetor_tutores[i].sexo);

            printf("CPF: ");
            for(int j = 0; j < 11; j++) {
                printf("%d", vetor_tutores[i].cpf[j]);
            }
            printf("\n");

            printf("Animais: ");
            for(int j = 0; j < 10; j++) {
                if(vetor_tutores[i].id_animais[j] != 0) {
                    printf("%d ", vetor_tutores[i].id_animais[j]);
                }
            }
            printf("\n");

            printf("CEP: ");
            for(int j = 0; j < 8; j++) {
                printf("%d", vetor_tutores[i].endereco.cep[j]);
            }
            printf("\n");

            printf("Rua: %s\n", vetor_tutores[i].endereco.rua);
            printf("Bairro: %s\n", vetor_tutores[i].endereco.bairro);
            printf("Cidade: %s\n", vetor_tutores[i].endereco.cidade);
            printf("Estado: %s\n", vetor_tutores[i].endereco.estado);
            printf("N�mero: %s\n", vetor_tutores[i].endereco.numero_casa);

            printf("Telefone: ");
            for(int j = 0; j < 11; j++) {
                printf("%d", vetor_tutores[i].contato.telefone[j]);
            }
            printf("\n");

            printf("Email: %s\n\n", vetor_tutores[i].contato.email);
        }
    }
    system("pause");
}

void tela_pesquisar() {
    int continuar, id;
    do {
        system("cls");

        printf("3 - Pesquisar Animal\n");
        printf("Digite o ID do animal: ");
        scanf("%d", &id); fflush(stdin);

        Animal a = cadastro_pesquisar_animal(id);

        if (a.ocupado == 1) {
            printf("Animal encontrado:\n");
            printf("Nome: %s\n", a.nome_animal);
            printf("Esp�cie: %s\n", a.especie);
            printf("Sexo: %c\n", a.sexo);
            printf("Ra�a: %s\n", a.raca);
            printf("Vacinas: %s\n", a.vacinas);
            printf("Vermifugado: %c\n", a.vermifugado);
            printf("Hist�rico: %s\n", a.historico);
            printf("Castrado: %c\n", a.castrado);
        } else {
            printf("Animal n�o encontrado.\n");
        }
        system("pause");
        continuar = tela_mensagem("Deseja pesquisar outro animal?");

    } while (continuar == 1);
}

void tela_pesquisar_tutor() {
    int continuar, id;
    do {
        system("cls");
        printf("5 - Pesquisar Tutor\n");
        printf("Digite o ID do tutor: ");
        scanf("%d", &id);
        fflush(stdin);

        Tutor t = cadastro_pesquisar_tutor(id);

        if (t.tutor_ocupado == 1) {
            printf("\nTutor encontrado:\n");
            printf("Nome: %s\n", t.nome_tutor);
            printf("Sexo: %c\n", t.sexo);

            printf("CPF: ");
            for(int j = 0; j < 11; j++) {
                printf("%d", t.cpf[j]);
            }
            printf("\n");

            printf("Animais: ");
            for(int j = 0; j < 10 && t.id_animais[j] != 0; j++) {
                printf("%d ", t.id_animais[j]);
            }
            printf("\n");

            printf("CEP: ");
            for(int j = 0; j < 8; j++) {
                printf("%d", t.endereco.cep[j]);
            }
            printf("\n");

            printf("Rua: %s\n", t.endereco.rua);
            printf("Bairro: %s\n", t.endereco.bairro);
            printf("Cidade: %s\n", t.endereco.cidade);
            printf("Estado: %s\n", t.endereco.estado);
            printf("N�mero: %s\n", t.endereco.numero_casa);

            printf("Telefone: ");
            for(int j = 0; j < 11; j++) {
                printf("%d", t.contato.telefone[j]);
            }
            printf("\n");

            printf("Email: %s\n", t.contato.email);
        } else {
            printf("\nTutor n�o encontrado.\n");
        }
        system("pause");
        continuar = tela_mensagem("Deseja pesquisar outro tutor?");

    } while (continuar == 1);
}


void tela_remover() {
    int continuar, id;

    do {
        system("cls");

        printf("4 - Remover Animal\n");
        printf("Digite o ID do animal a ser removido: ");
        scanf("%d", &id); fflush(stdin);

        if (cadastro_remover_animal(id)) {
            printf("Animal removido com sucesso.\n");
        } else {
            printf("Animal n�o encontrado.\n");
        }

        system("pause");

        continuar = tela_mensagem("Deseja remover outro animal?");

    } while (continuar == 1);
}


void tela_remover_tutor() {
    int continuar, id;
    do {
        system("cls");
        printf("7 - Remover Tutor\n");
        printf("Digite o ID do tutor a ser removido: ");
        scanf("%d", &id);
        fflush(stdin);

        if (cadastro_remover_tutor(id)) {
            printf("Tutor removido com sucesso.\n");
        } else {
            printf("Tutor n�o encontrado.\n");
        }

        system("pause");
        continuar = tela_mensagem("Deseja remover outro tutor?");

    } while (continuar == 1);
}


int tela_sair() {
    system("cls");
    printf("5 - Sair\n");

    return tela_mensagem("Deseja realmente sair?");
}

int tela_mensagem(char *mensagem) {
    char resp;
    do {
        printf("%s (s/n): ", mensagem);
        scanf(" %c", &resp);
        fflush(stdin);
        resp = toupper(resp);

        if (resp == 'S') return 1;
        if (resp == 'N') return 0;

        printf("Erro: Digite apenas 's' ou 'n'!\n");

    } while (1);
}

//////////////////////// FUN��ES///////////////////////////////////////////


int cadastro_verificar_capacidade_maxima_animais() {

    return total_animais >= NUM_MAX_ANIMAIS;
}

int cadastro_verificar_capacidade_maxima_tutores() {

    return total_tutores >= NUM_MAX_TUTORES;
}

void cadastro_inicializar_animais() {

    total_animais = 0;

    for (int i = 0; i < NUM_MAX_ANIMAIS; i++) {
        vetor_animais[i].ocupado = 0;
    }
}

void cadastro_inicializar_tutores() {

    total_tutores = 0;

    for (int i = 0; i < NUM_MAX_TUTORES; i++) {
        vetor_tutores[i].tutor_ocupado = 0;
    }
}

void cadastro_inicializar_arquivo_tutores() {
    FILE *fp = fopen(caminho_arquivo_tutores, "r");
    if (fp == NULL) {
        fp = fopen(caminho_arquivo_tutores, "w");
        fprintf(fp, "%d\n", total_tutores);
        fclose(fp);
    } else {
        fclose(fp);
    }
}

void cadastro_inicializar_arquivo_animais() {
    FILE *fp = fopen(caminho_arquivo_animais, "r");
    if (fp == NULL) {
        fp = fopen(caminho_arquivo_animais, "w");
        fprintf(fp, "%d\n", total_animais);
        fclose(fp);
    } else {
        fclose(fp);
    }
}

Tutor animais_id_tutor_inicializador() {
    Tutor inicializador;

    inicializador.tutor_ocupado = 0;
    strcpy(inicializador.nome_tutor, "");
    inicializador.id_tutor = 0;

    // Inicializa vetor de IDs de animais
    for(int i = 0; i < 10; i++) {
        inicializador.id_animais[i] = 0;
    }

    // Inicializa CPF
    for(int i = 0; i < 11; i++) {
        inicializador.cpf[i] = 0;
    }

    inicializador.sexo = ' ';

    for(int i = 0; i < 8; i++) {
        inicializador.endereco.cep[i] = 0;
    }
    strcpy(inicializador.endereco.rua, "");
    strcpy(inicializador.endereco.bairro, "");
    strcpy(inicializador.endereco.cidade, "");
    strcpy(inicializador.endereco.estado, "");
    strcpy(inicializador.endereco.numero_casa, "");

    for(int i = 0; i < 11; i++) {
        inicializador.contato.telefone[i] = 0;
    }
    strcpy(inicializador.contato.email, "");

    return inicializador;
}

void cadastro_carregar_dados_arquivo_tutores() {
    FILE *fp = fopen(caminho_arquivo_tutores, "r");
    if (fp == NULL) return;

    fscanf(fp, "%d\n", &total_tutores);

    for (int i = 0; i < total_tutores; i++) {
        Tutor tutor = {0};

        fgets(tutor.nome_tutor, 256, fp);
        tutor.nome_tutor[strcspn(tutor.nome_tutor, "\n")] = 0;

        fscanf(fp, "%d\n", &tutor.id_tutor);

        for(int j = 0; tutor.id_animais[j != 0]; j++){
            fscanf(fp, "%d", &tutor.id_animais[j]);
        }
        fscanf(fp, "\n");

        for(int j = 0; j < 11; j++) {
            fscanf(fp, "%1d", &tutor.cpf[j]);
        }
        fscanf(fp, "\n");

        fscanf(fp, "%c\n", &tutor.sexo);

        for(int j = 0; j < 8; j++){
            fscanf(fp, "%1d", &tutor.endereco.cep[j]); // CORRE��O AQUI
        }
        fscanf(fp, "\n");

        fgets(tutor.endereco.rua, 120, fp);
        tutor.endereco.rua[strcspn(tutor.endereco.rua, "\n")] = 0;

        fgets(tutor.endereco.bairro, 120, fp); // CORRE��O AQUI
        tutor.endereco.bairro[strcspn(tutor.endereco.bairro, "\n")] = 0;

        fgets(tutor.endereco.cidade, 80, fp); // CORRE��O AQUI
        tutor.endereco.cidade[strcspn(tutor.endereco.cidade, "\n")] = 0;

        fgets(tutor.endereco.estado, 50, fp); // CORRE��O AQUI
        tutor.endereco.estado[strcspn(tutor.endereco.estado, "\n")] = 0;

        fgets(tutor.endereco.numero_casa, 50, fp); // CORRE��O AQUI
        tutor.endereco.numero_casa[strcspn(tutor.endereco.numero_casa, "\n")] = 0;

        for(int j = 0; j < 11; j++) {
            fscanf(fp, "%1d", &tutor.contato.telefone[j]);
        }
        fscanf(fp, "\n");

        fgets(tutor.contato.email, 120, fp);
        tutor.contato.email[strcspn(tutor.contato.email, "\n")] = 0;

        tutor.tutor_ocupado = 1;
        vetor_tutores[i] = tutor;
    }
    fclose(fp);
}

void cadastro_carregar_dados_arquivo_animais() {
    FILE *fp = fopen(caminho_arquivo_animais, "r");

    if (fp == NULL) return;

    fscanf(fp, "%d ", &total_animais);

    for (int i = 0; i < total_animais; i++) {
        Animal a;

        fscanf(fp, "%d %d ", &a.id_animal, &a.id_tutor);

        fgets(a.nome_animal, 256, fp);

        a.nome_animal[strcspn(a.nome_animal, "\n")] = 0;

        fgets(a.especie, 256, fp);
        a.especie[strcspn(a.especie, "\n")] = 0;

        fscanf(fp, "%c ", &a.sexo);

        fgets(a.raca, 256, fp);
        a.raca[strcspn(a.raca, "\n")] = 0;

        fgets(a.vacinas, 512, fp);
        a.vacinas[strcspn(a.vacinas, "\n")] = 0;

        fscanf(fp, "%c ", &a.vermifugado);

        fgets(a.historico, 512, fp);
        a.historico[strcspn(a.historico, "\n")] = 0;

        fscanf(fp, "%c ", &a.castrado);

        a.ocupado = 1;

        vetor_animais[i] = a;
    }
    fclose(fp);
}

void cadastro_salvar_dados_arquivo_tutores() {
    FILE *fp = fopen(caminho_arquivo_tutores, "w");
    if (fp == NULL) return;

    fprintf(fp, "%d\n", total_tutores);

    for (int i = 0; i < NUM_MAX_TUTORES; i++) {
        if (vetor_tutores[i].tutor_ocupado == 1) {
            // Dados b�sicos
            fprintf(fp, "%s\n", vetor_tutores[i].nome_tutor);
            fprintf(fp, "%d\n", vetor_tutores[i].id_tutor);

            // IDs dos animais
            for(int j = 0; j < 10; j++) {
                fprintf(fp, "%d ", vetor_tutores[i].id_animais[j]);
            }
            fprintf(fp, "\n");

            // CPF (como string)
            for(int j = 0; j < 11; j++) {
                fprintf(fp, "%d", vetor_tutores[i].cpf[j]);
            }
            fprintf(fp, "\n");

            // Sexo
            fprintf(fp, "%c\n", vetor_tutores[i].sexo);

            // Endere�o
            for(int j = 0; j < 8; j++) {
                fprintf(fp, "%d", vetor_tutores[i].endereco.cep[j]);
            }
            fprintf(fp, "\n");

            fprintf(fp, "%s\n", vetor_tutores[i].endereco.rua);
            fprintf(fp, "%s\n", vetor_tutores[i].endereco.bairro);
            fprintf(fp, "%s\n", vetor_tutores[i].endereco.cidade);
            fprintf(fp, "%s\n", vetor_tutores[i].endereco.estado);
            fprintf(fp, "%s\n", vetor_tutores[i].endereco.numero_casa);

            // Contato
            for(int j = 0; j < 11; j++) {
                fprintf(fp, "%d", vetor_tutores[i].contato.telefone[j]);
            }
            fprintf(fp, "\n");

            fprintf(fp, "%s\n", vetor_tutores[i].contato.email);
        }
    }
    fclose(fp);
}

void cadastro_salvar_dados_arquivo_animais() {
    FILE *fp = fopen(caminho_arquivo_animais, "w");

    if (fp == NULL) return;

    fprintf(fp, "%d\n", total_animais);

    for (int i = 0; i < NUM_MAX_ANIMAIS; i++) {
        if (vetor_animais[i].ocupado == 1) {
            fprintf(fp, "%d\n%d\n", vetor_animais[i].id_animal, vetor_animais[i].id_tutor);
            fprintf(fp, "%s\n", vetor_animais[i].nome_animal);
            fprintf(fp, "%s\n", vetor_animais[i].especie);
            fprintf(fp, "%c\n", vetor_animais[i].sexo);
            fprintf(fp, "%s\n", vetor_animais[i].raca);
            fprintf(fp, "%s\n", vetor_animais[i].vacinas);
            fprintf(fp, "%c\n", vetor_animais[i].vermifugado);
            fprintf(fp, "%s\n", vetor_animais[i].historico);
            fprintf(fp, "%c\n", vetor_animais[i].castrado);
        }
    }
    fclose(fp);
}

int verificar_id_tutor_existente(int id) {

    for (int i = 0; i < NUM_MAX_TUTORES; i++) {
        if (vetor_tutores[i].tutor_ocupado == 1 && vetor_tutores[i].id_tutor == id)
        return 1;
    }
    return 0;
}

int verificar_id_animal_existente(int id) {

    for (int i = 0; i < NUM_MAX_ANIMAIS; i++) {
        if (vetor_animais[i].ocupado == 1 && vetor_animais[i].id_animal == id)
            return 1;
    }
    return 0;
}

int verificar_id_tutor_existente2(int id_tutor) {
    FILE *fp = fopen(caminho_arquivo_tutores, "r");
    if (fp == NULL) return 0;

    int total, id;

    fscanf(fp, "%d", &total);

    for (int i = 0; i < total; i++) {
        fscanf(fp, "%d", &id);
        if (id == id_tutor) {
            fclose(fp);
            return 1;
        }
        char lixo[256];
        fgets(lixo, 256, fp);
        fgets(lixo, 256, fp);
        fgets(lixo, 256, fp);
        fgets(lixo, 256, fp);
    }
    fclose(fp);
    return 0;
}

void cadastro_inserir_tutor(Tutor tutor) {

    for (int i = 0; i < NUM_MAX_TUTORES; i++) {
        if (vetor_tutores[i].tutor_ocupado == 1 && vetor_tutores[i].id_tutor == tutor.id_tutor) {
            printf("\nErro: J� existe um tutor com este ID.\n");
            system("pause");
            return;
        }
    }

    for (int i = 0; i < NUM_MAX_TUTORES; i++) {
        if (vetor_tutores[i].tutor_ocupado == 0) {
            vetor_tutores[i] = tutor;
            vetor_tutores[i].tutor_ocupado = 1;
            total_tutores++;
            printf("\nTutor cadastrado com sucesso!\n");
            system("pause");
            break;
        }
    }

}

void cadastro_inserir_animal(Animal a) {
    for (int i = 0; i < NUM_MAX_ANIMAIS; i++) {
        if (vetor_animais[i].ocupado == 1 && vetor_animais[i].id_animal == a.id_animal) {
            printf("\nErro: J� existe um animal com este ID.\n");
            system("pause");
            return;
        }
    }
    for (int i = 0; i < NUM_MAX_ANIMAIS; i++) {
        if (vetor_animais[i].ocupado == 0) {
            vetor_animais[i] = a;
            vetor_animais[i].ocupado = 1;
            total_animais++;
            printf("\nAnimal cadastrado com sucesso!\n");
            system("pause");
            break;
        }
    }
}

Tutor cadastro_pesquisar_tutor(int id) {
    for (int i = 0; i < NUM_MAX_TUTORES; i++) {
        if (vetor_tutores[i].tutor_ocupado == 1 && vetor_tutores[i].id_tutor == id){

            return vetor_tutores[i];

        }

    }

    Tutor vazio = {0};
    return vazio;
}

Animal cadastro_pesquisar_animal(int id) {
    for (int i = 0; i < NUM_MAX_ANIMAIS; i++) {
        if (vetor_animais[i].ocupado == 1 && vetor_animais[i].id_animal == id){

            return vetor_animais[i];

        }

    }

    Animal vazio = {0};
    return vazio;
}

int cadastro_remover_tutor(int id) {

    for (int i = 0; i < NUM_MAX_TUTORES; i++) {
        if (vetor_tutores[i].tutor_ocupado == 1 && vetor_tutores[i].id_tutor == id) {

            vetor_tutores[i].tutor_ocupado = 0;
            total_tutores--;

            return 1;
        }
    }
    return 0;
}

int cadastro_remover_animal(int id) {

    for (int i = 0; i < NUM_MAX_ANIMAIS; i++) {
        if (vetor_animais[i].ocupado == 1 && vetor_animais[i].id_animal == id) {

            vetor_animais[i].ocupado = 0;
            total_animais--;

            return 1;
        }
    }
    return 0;
}
